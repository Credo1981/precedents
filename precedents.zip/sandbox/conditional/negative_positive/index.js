// Определение отрицательное число или положительное
var people_number = prompt('input number negative or positive');

if (people_number > 0) {
    console.log('number positive');
}else if(people_number < 0) {
    console.log('number negative');
}else {
    console.log('number zero');
}