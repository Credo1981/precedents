var access = document.getElementById("code9");
console.log(access);
var code = access.innerHTML;
console.log(code);
code = code + " midnight";
alert(code);