var obj = {
    "Проект":
    [
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Алеев А.В.",
            "BeginDate": "/Date(1553058254000)/",
            "EndDate": "/Date(1554613454000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Алеев А.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Алеев А.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Ужин В.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Ужин В.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Клиентский программист",
            "EmployeeName": "Зоева А.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Клиентский программист",
            "EmployeeName": "Зоева А.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Программист",
            "EmployeeName": "Иванов В.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Программист",
            "EmployeeName": "Иванов В.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
    ],
    "Руководители":
    [
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Алеев А.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Алеев А.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Ужин В.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Серверный программист",
            "EmployeeName": "Ужин В.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Клиентский программист",
            "EmployeeName": "Зоева А.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Клиентский программист",
            "EmployeeName": "Зоева А.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Программист",
            "EmployeeName": "Иванов В.В.",
            "BeginDate": "/Date(1552244400000)/",
            "EndDate": "/Date(1552590000000)/",
            "SorOrder": 4
        },
        {
            "RoleName": "Программист",
            "EmployeeName": "Иванов В.В.",
            "BeginDate": "/Date(1557082800000)/",
            "EndDate": "/Date(1557255600000)/",
            "SorOrder": 4
        },
    ]
};
console.log(JSON.stringify(obj));