function type () {
    var a = 17;
    var b = a();
    return b;
}
type ();