function reference () {
    var a = 2;
    var b = 3;
    return c;
}

reference ();