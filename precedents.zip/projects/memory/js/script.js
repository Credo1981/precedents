console.log('new_script');


var btn = document.getElementsByTagName('button');

var el_memory_digit = document.getElementById('memory_digit');

var el_score = document.getElementById('score'),
	el_timer = document.getElementById('timer');

var state = {
    score : 0,
    memory_digit : 0,
    timer: 500
};

// Счет
el_score.textContent = state.score;

// Поле ввода таймера
el_timer.addEventListener('input', function () {
    let items = el_timer.value;
    state.timer = items;
    el_timer.value = state.timer;
});

// Кнопка "Start"
btn[0].addEventListener('click', function() {
	// Команды обнуления параметров
	btn[1].style.backgroundColor = 'lightgrey';
	btn[2].style.backgroundColor = 'lightgrey';
	btn[3].style.backgroundColor = 'lightgrey';
	el_memory_digit.style.display = 'block';
	chouse_numbers.style.display = 'none';
	// Конец команд обнуления параметров

    function GenerateNewDigit() {
        var rand = (Math.floor(Math.random() * 9) + 1);
        return rand;
    }

    function three() {
        digit3 = [];
        for (var i = 0; i < 3; i++) {
            digit3.push(GenerateNewDigit());
        }
        return digit3;
    }


    var arrGenerateRandomThree = three()
        // Функция для убирания запятых
    function remove_coma(el_arr) {
        var item = el_arr.join('');
        return item;
    }
    // Функция которая возвращает [0] элемент массива
    function first_elem_arr(arr) {
        item_arr = arr[0];
        return item_arr;
    }

    state.memory_digit = remove_coma(arrGenerateRandomThree);
    var falseNumber1 = remove_coma(three());
    var falseNumber2 = remove_coma(three());
    // Вывод трёхзначного числа
    el_memory_digit.textContent = state.memory_digit;
    var randon_btn = GenerateNewDigit();
    if (randon_btn < 3) {
        btn[1].textContent = state.memory_digit;
        btn[2].textContent = falseNumber1;
        btn[3].textContent = falseNumber2;
    } else if (randon_btn < 6) {
        btn[1].textContent = falseNumber1;
        btn[2].textContent = state.memory_digit;
        btn[3].textContent = falseNumber2;
    } else {
        btn[1].textContent = falseNumber1;
        btn[2].textContent = falseNumber2;
        btn[3].textContent = state.memory_digit;
    }

    // функция для скрытия запоминаемого числа
	setTimeout(function () {el_memory_digit.style.display = 'none'}, state.timer);
	// функция для отображения таблицы с вариантами ответов пользователя
	setTimeout(function () {chouse_numbers.style.display = 'block'}, state.timer);
	console.log(state.timer);
});


// Кнопки выбора
btn[1].addEventListener('click', function () {
	if(btn[1].textContent == state.memory_digit) {
		el_score.textContent = ++state.score;
		btn[1].style.backgroundColor = 'green';
	} else {
		el_score.textContent = --state.score;
		btn[1].style.backgroundColor = 'red';
	}
	setTimeout(function() {btn[0].click()}, 200);
});

btn[2].addEventListener('click', function () {
	if(btn[2].textContent == state.memory_digit) {
		el_score.textContent = ++state.score;
		btn[2].style.backgroundColor = 'green';
	} else {
		el_score.textContent = --state.score;
		btn[2].style.backgroundColor = 'red';
	}
	setTimeout(function() {btn[0].click()}, 200);
});

btn[3].addEventListener('click', function () {
	if(btn[3].textContent == state.memory_digit) {
		el_score.textContent = ++state.score;
		btn[3].style.backgroundColor = 'green';
	} else {
		el_score.textContent = --state.score;
		btn[3].style.backgroundColor = 'red';
	}
	setTimeout(function() {btn[0].click()}, 200);
});
